<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'certificatebeautifuldatainfo_user', language 'pt_br', version '5.2'.
 *
 * @package     certificatebeautifuldatainfo_user
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['address'] = 'Endereço do usuário.';
$string['alternatename'] = 'Nome alternativo do usuário.';
$string['calendartype'] = 'Tipo de calendário preferido do usuário.';
$string['city'] = 'Cidade do usuário.';
$string['country'] = 'Código do país do usuário.';
$string['currentlogin'] = 'Registro de data e hora do login atual do usuário.';
$string['department'] = 'Departamento do usuário.';
$string['description'] = 'Descrição do usuário.';
$string['email'] = 'Endereço de e-mail do usuário.';
$string['firstaccess'] = 'Registro de data e hora do primeiro acesso do usuário.';
$string['firstname'] = 'Primeiro nome do usuário.';
$string['fullname'] = 'Nome completo do usuário, gerado pela função fullname().';
$string['id'] = 'Identificador único para cada usuário.';
$string['idnumber'] = 'Número de identificação do usuário.';
$string['institution'] = 'Instituição do usuário.';
$string['lang'] = 'Idioma preferido do usuário.';
$string['lastaccess'] = 'Registro de data e hora do último acesso do usuário.';
$string['lastip'] = 'Endereço IP do último acesso do usuário.';
$string['lastlogin'] = 'Registro de data e hora do último login do usuário.';
$string['lastname'] = 'Último nome do usuário.';
$string['middlename'] = 'Nome do meio do usuário.';
$string['phone1'] = 'Número de telefone principal do usuário.';
$string['phone2'] = 'Número de telefone secundário do usuário.';
$string['pluginname'] = 'Dados do usuário';
$string['privacy:metadata'] = 'O plugin não armazena nenhum dado pessoal.';
$string['timecreated'] = 'Registro de data e hora da criação da conta do usuário.';
$string['timemodified'] = 'Registro de data e hora da última modificação da conta do usuário.';
$string['timezone'] = 'Fuso horário preferido do usuário.';
$string['username'] = 'Nome de usuário do usuário.';
