<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_meta', language 'pt_br', version '5.2'.
 *
 * @package     enrol_meta
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addgroup'] = 'Adicionar ao grupo';
$string['coursesort'] = 'Ordenar a lista de cursos de origem';
$string['coursesort_help'] = 'Isso determina se a lista de cursos que podem ser vinculados é ordenada por ordem de classificação (ou seja, a ordem definida em Administração do site > Cursos > Gerenciar cursos e categorias) ou alfabeticamente pela configuração do curso.';
$string['creategroup'] = 'Criar novo grupo';
$string['defaultgroupnametext'] = 'Curso {$a->name} {$a->increment}';
$string['enrolmetasynctask'] = 'Tarefa de sincronização das meta inscrições';
$string['linkedcourse'] = 'Vincular curso';
$string['meta:config'] = 'Configura meta instâncias de inscrição';
$string['meta:selectaslinked'] = 'Selecionar curso como meta curso';
$string['meta:unenrol'] = 'Cancelar inscrição de usuários suspensos';
$string['nosyncroleids'] = 'Papéis que não estão sincronizados';
$string['nosyncroleids_desc'] = 'Por padrão, todas as atribuições de papel em nível de curso são sincronizadas do curso de origem para o curso de destino. Os papéis selecionados aqui não serão incluídos no processo de sincronização.';
$string['pluginname'] = 'Curso meta link';
$string['pluginname_desc'] = 'O plugin de inscrição Curso meta link sincroniza inscrições e papéis do curso de origem com o curso de destino.';
$string['privacy:metadata:core_group'] = 'O plugin de inscrição curso meta link pode criar um novo grupo ou usar um grupo existente para adicionar participantes do curso de origem.';
$string['samemetacourse'] = 'Você não pode adicionar um meta link no mesmo curso.';
$string['syncall'] = 'Sincroniza todos os usuários inscritos';
$string['syncall_desc'] = 'Se habilitado, todos os estudantes inscritos são sincronizados do curso de origem, mesmo que não tenham um papel nele. Caso contrário, apenas estudantes com pelo menos um papel são inscritos no curso de destino.';
$string['unknownmetacourse'] = 'Nome curto desconhecido do meta curso';
$string['wscannotcreategroup'] = 'Sem permissão para criar grupo no curso vinculado id = {$a}.';
$string['wsinvalidcourse'] = 'O curso com id = {$a} não existe ou não tem permissão para vincular uma inscrição meta curso.';
$string['wsinvalidmetacourse'] = 'O meta curso com ID = {$a} não existe ou você não tem permissão para adicionar instância de inscrição.';
$string['wsnoinstancesspecified'] = 'Nenhuma instância definida';
