<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'tiny_media', language 'pt_br', version '5.2'.
 *
 * @package     tiny_media
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addcaptionstrack'] = 'Adicionar faixa de legenda';
$string['addchapterstrack'] = 'Adicionar faixa de capítulo';
$string['adddescriptionstrack'] = 'Adicionar faixa de descrição';
$string['addfilesdrop'] = 'Arraste e solte uma imagem para enviar, ou clique para selecionar';
$string['addmediafilesdrop'] = 'Arraste e solte um arquivo de áudio/vídeo para enviar ou clique para selecionar';
$string['addmediathumbnaildrop'] = 'Arraste e solte um arquivo de miniatura de imagem para enviar ou clique para selecionar';
$string['addmetadatatrack'] = 'Adicionar faixa de metadados';
$string['addsource'] = 'Adicionar fonte alternativa';
$string['addsource_help'] = 'É recomendável fornecer uma fonte de mídia alternativa, pois os navegadores de desktop e móveis suportam diferentes formatos de arquivo.';
$string['addsubtitlestrack'] = 'Adicionar faixa de legenda';
$string['addurl'] = 'Adicionar';
$string['advancedsettings'] = 'Configurações avançadas';
$string['alttext_help'] = 'Selecione se a descrição alternativa do texto não for necessária para esta imagem.';
$string['audio'] = 'Áudio';
$string['audiosourcelabel'] = 'URL de origem do áudio';
$string['autoplay'] = 'Reproduzir automaticamente';
$string['back'] = 'Voltar';
$string['browseembedimagerepositories'] = 'Explorar repositórios';
$string['browserepositories'] = 'Navegar nos repositórios...';
$string['browserepositoriesimage'] = 'Procurar repositórios';
$string['captions'] = 'Legendas';
$string['captions_help'] = 'As legendas podem ser usadas para descrever tudo o que acontece na faixa, incluindo sons não verbais, como um telefone tocando.';
$string['captionssourcelabel'] = 'URL da faixa de legenda';
$string['changethumbnail'] = 'Alterar miniatura';
$string['chapters'] = 'Capítulos';
$string['chapters_help'] = 'Os títulos dos capítulos podem ser fornecidos para uso na navegação do recurso de mídia.';
$string['chapterssourcelabel'] = 'URL da faixa de capítulo';
$string['constrain'] = 'Manter proporção';
$string['controls'] = 'Exibir controles';
$string['createmedia'] = 'Inserir mídia';
$string['customsize_help'] = 'Para melhor experiência de visualização, a largura e altura do vídeo serão ajustadas juntas, mantendo a proporção original.';
$string['default'] = 'Padrão';
$string['deleteembeddedthumbnail'] = 'Excluir miniatura';
$string['deleteembeddedthumbnailwarning'] = 'Tem certeza de que deseja remover a miniatura incorporada?';
$string['deleteimage'] = 'Excluir imagem';
$string['deleteimagewarning'] = 'Tem certeza de que deseja remover a imagem?';
$string['deletemedia'] = 'Excluir mídia';
$string['deletemediathumbnail'] = 'Excluir miniatura de mídia';
$string['deletemediathumbnailwarning'] = 'Tem certeza de que deseja remover a miniatura da mídia?';
$string['deletemediawarning'] = 'Tem certeza de que deseja remover a mídia?';
$string['deleteselected'] = 'Excluir arquivos selecionados';
$string['deletethumbnail'] = 'Excluir miniatura personalizada';
$string['descriptions'] = 'Descrições';
$string['descriptions_help'] = 'As descrições de áudio podem ser usadas para fornecer uma narração que explique detalhes visuais não aparentes apenas no áudio.';
$string['descriptionssourcelabel'] = 'URL da faixa de descrição';
$string['displayoptions'] = 'Opções de exibição';
$string['enteralt'] = 'Como você descreveria esta imagem para alguém que não pode vê-la?';
$string['entername'] = 'Nome';
$string['entersource'] = 'URL da fonte';
$string['entertitle'] = 'Título da mídia';
$string['enterurl'] = 'Adicionar via URL';
$string['enterurlor'] = 'Ou adicionar via URL';
$string['filemanager'] = 'Gerenciador de arquivos';
$string['hasmissingfiles'] = 'Aviso! Os seguintes arquivos referenciados na área de texto parecem estar ausentes:';
$string['height'] = 'Altura';
$string['helplinktext'] = 'Assistente de mídia';
$string['imagealternativetext'] = 'Texto alternativo';
$string['imagebuttontitle'] = 'Imagem';
$string['imagedetails'] = 'Detalhes da imagem';
$string['imageproperties'] = 'Propriedades da imagem';
$string['imagesize'] = 'Tamanho da imagem';
$string['imageurlrequired'] = 'Uma imagem deve ter um URL válido.';
$string['insertimage'] = 'Inserir imagem';
$string['insertmedia'] = 'Inserir mídia';
$string['insertmediathumbnail'] = 'Inserir miniatura da mídia';
$string['label'] = 'Rótulo';
$string['languagesavailable'] = 'Idiomas disponíveis';
$string['languagesinstalled'] = 'Idiomas instalados';
$string['link'] = 'Link';
$string['linkcustomsize_help'] = 'Para melhor experiência de visualização, a largura e altura da mídia vinculada serão ajustadas juntas com a proporção de 16:9.';
$string['loading'] = 'Preparando a imagem';
$string['loadingembedthumbnail'] = 'Preparando a miniatura incorporada';
$string['loadingmedia'] = 'Preparando a mídia';
$string['loop'] = 'Loop';
$string['managefiles'] = 'Gerenciar arquivos';
$string['media:use'] = 'Usar TinyMCE Inserir Mídia';
$string['mediabuttontitle'] = 'Multimídia';
$string['mediadetails'] = 'Detalhes da mídia';
$string['medialinktypeselector'] = 'Selecionar tipo de mídia';
$string['mediamanagerbuttontitle'] = 'Gerenciar mídia';
$string['mediamanagerproperties'] = 'Gerenciar mídia';
$string['medianotavailable'] = 'Mídia não disponível';
$string['medianotavailabledesc'] = 'Erro ao carregar a seguinte URL de mídia: {$a}';
$string['mediasize'] = 'Tamanho da mídia';
$string['mediatitle'] = 'Título';
$string['mediaurlrequired'] = 'Um arquivo de áudio/vídeo deve ter uma URL válida.';
$string['metadata'] = 'Metadados';
$string['metadata_help'] = 'As faixas de metadados, para uso a partir de um script, podem ser usadas somente se o player suportar metadados.';
$string['metadatasourcelabel'] = 'URL de rastreamento de metadados';
$string['missingfiles'] = 'Arquivos ausentes';
$string['mute'] = 'Silenciado';
$string['next'] = 'Próximo';
$string['nofilepicker'] = 'Cole um link para um arquivo de áudio/vídeo no campo abaixo ou<br>clique no botão Procurar Repositórios.';
$string['nofilepickerrepository'] = 'Cole um link de {$a} no campo abaixo.';
$string['onlymediafiles'] = 'Aceita apenas arquivos de mídia';
$string['playbacksettings'] = 'Configurações de reprodução';
$string['pluginname'] = 'Inserir mídia';
$string['presentation'] = 'Essa imagem é apenas decorativa';
$string['presentationoraltrequired'] = 'As imagens precisam de uma descrição, a menos que sejam marcadas como apenas decorativas.';
$string['privacy:metadata'] = 'O plugin de mídia para TinyMCE não armazena nenhum dado pessoal.';
$string['remove'] = 'Remover';
$string['repositorynotpermitted'] = 'Cole um link da imagem no campo abaixo.';
$string['repositoryuploadnotpermitted'] = 'Cole um link da imagem no campo abaixo ou<br>clique no botão Procurar Repositórios.';
$string['saveimage'] = 'Salvar';
$string['size'] = 'Largura x altura (em pixels)';
$string['sizecustom'] = 'Tamanho personalizado';
$string['sizecustom_help'] = 'Para preservar a qualidade da imagem, a largura e a altura são ajustadas juntas, mantendo as proporções originais.';
$string['sizeoriginal'] = 'Tamanho original';
$string['srclang'] = 'Idioma';
$string['subtitles'] = 'Legendas';
$string['subtitles_help'] = 'As legendas podem ser usadas para fornecer uma transcrição ou tradução do diálogo.';
$string['subtitlesandcaptions'] = 'Legendas e legendas ocultas';
$string['subtitlessourcelabel'] = 'URL da faixa de legendas';
$string['thumbnail'] = 'Miniatura da mídia';
$string['tracks'] = 'Legendas e Closed Captions (CC)';
$string['tracks_help'] = 'Legendas, closed captions, capítulos e descrições podem ser adicionados através de um arquivo de formato WebVTT (Web Video Text Tracks). Os rótulos das faixas serão mostrados no menu suspenso de seleção. Para cada tipo de faixa, qualquer faixa definida como padrão será pré-selecionada no início do vídeo.';
$string['unusedfilesdesc'] = 'Os seguintes arquivos incorporados não são usados na área de texto:';
$string['unusedfilesheader'] = 'Arquivos não usados';
$string['unusedfilesremovalnotice'] = 'Quaisquer arquivos não utilizados serão excluídos automaticamente ao salvar as alterações.';
$string['updatemedia'] = 'Atualizar mídia';
$string['uploading'] = 'Enviando';
$string['uploadthumbnail'] = 'Adicionar miniatura personalizada';
$string['video'] = 'Vídeo';
$string['videoheight'] = 'Altura do vídeo';
$string['videosourcelabel'] = 'URL de origem do vídeo';
$string['videowidth'] = 'Largura do vídeo';
$string['width'] = 'Largura';
