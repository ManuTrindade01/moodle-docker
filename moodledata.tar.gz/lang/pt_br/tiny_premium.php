<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'tiny_premium', language 'pt_br', version '5.2'.
 *
 * @package     tiny_premium
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['accessibilitycheckerinfo'] = 'O Verificador de Acessibilidade Premium substituirá o Verificador de Acessibilidade padrão para usuários que tiverem acesso a ele.';
$string['apikey'] = 'Chave de API';
$string['apikey_desc'] = 'Sua chave de API está disponível na página da sua conta do <a target="_blank" href="https://www.tiny.cloud">Tiny Cloud</a> se você tiver adquirido uma assinatura, ou se estiver em um teste gratuito.';
$string['emptyapikeywarning'] = 'Os plugins Premium do TinyMCE habilitados não estarão disponíveis até que uma chave de API seja adicionada.';
$string['helplinktext'] = 'Plugins Premium';
$string['invalidpath'] = 'Você não forneceu um caminho válido para o pacote independente do TinyMCE. Verifique a página <a href="{$a}">Configurações gerais do TinyMCE</a>.';
$string['invalidurl'] = 'O URL inserido é inválido';
$string['pluginname'] = 'TinyMCE premium';
$string['pluginnotfound'] = 'Plugin Tiny Premium {$a} não encontrado.';
$string['pluginsource'] = 'Fonte do plugin';
$string['pluginsource:cloud'] = 'Tiny Cloud';
$string['pluginsource:selfhosted'] = 'Auto-hospedado';
$string['pluginsource_desc'] = 'Selecione a fonte dos plugins Tiny Premium. Se você selecionar "Tiny Cloud", será necessário fornecer uma chave de API. Se você selecionar "Auto-hospedado", será necessário fornecer um caminho válido para o TinyMCE na página <a href="{$a}">Configurações gerais do TinyMCE</a>.';
$string['premium:accesspremium'] = 'Acessar funções TinyMCE Premium';
$string['premium:use'] = 'Usar TinyMCE Premium';
$string['premium:usea11ychecker'] = 'Usar TinyMCE Premium Verificador de Acessibilidade';
$string['premium:useadvtable'] = 'Usar TinyMCE Premium Tabela Avançada';
$string['premium:useautocorrect'] = 'Usar TinyMCE Premium Correção Ortográfica Automática';
$string['premium:usecasechange'] = 'Usar TinyMCE Premium Alteração de Caixa';
$string['premium:usechecklist'] = 'Usar TinyMCE Premium Lista de Verificação';
$string['premium:useeditimage'] = 'Usar TinyMCE Premium Edição Aprimorada de Imagens';
$string['premium:useexport'] = 'Usar TinyMCE Premium Exportação';
$string['premium:usefootnotes'] = 'Usar TinyMCE Premium Notas de Rodapé';
$string['premium:useformatpainter'] = 'Usar TinyMCE Premium Pincel de Formatação';
$string['premium:uselinkchecker'] = 'Usar TinyMCE Premium Verificador de Links';
$string['premium:usemath'] = 'Usar TinyMCE Premium Ferramenta de Matemática';
$string['premium:usepageembed'] = 'Usar TinyMCE Premium Incorporação de Página';
$string['premium:usepermanentpen'] = 'Usar TinyMCE Premium Caneta Permanente';
$string['premium:usepowerpaste'] = 'Usar TinyMCE Premium Powerpaste';
$string['premium:usetableofcontents'] = 'Usar TinyMCE Premium Sumário';
$string['premium:usetinymcespellchecker'] = 'Usar TinyMCE Premium Verificador Ortográfico Pro';
$string['premium:usetypography'] = 'Usar TinyMCE Premium Tipografia Avançada';
$string['premiumplugin:a11ychecker'] = 'Verificador de acessibilidade';
$string['premiumplugin:advtable'] = 'Tabela Avançada';
$string['premiumplugin:autocorrect'] = 'Correção Automática de Ortografia';
$string['premiumplugin:casechange'] = 'Alterar Caixa';
$string['premiumplugin:checklist'] = 'Lista de Verificação';
$string['premiumplugin:editimage'] = 'Edição Avançada de Imagem';
$string['premiumplugin:export'] = 'Exportar';
$string['premiumplugin:footnotes'] = 'Notas de Rodapé';
$string['premiumplugin:formatpainter'] = 'Pincel de Formatação';
$string['premiumplugin:linkchecker'] = 'Verificador de Links';
$string['premiumplugin:math'] = 'Ferramenta de Matemática';
$string['premiumplugin:pageembed'] = 'Incorporar Página';
$string['premiumplugin:permanentpen'] = 'Caneta Permanente';
$string['premiumplugin:powerpaste'] = 'Powerpaste';
$string['premiumplugin:tableofcontents'] = 'Sumário';
$string['premiumplugin:tinymcespellchecker'] = 'Verificador Ortográfico Pro';
$string['premiumplugin:typography'] = 'Tipografia Avançada';
$string['premiumplugins'] = 'Plugins Premium';
$string['premiumplugins_desc'] = 'O acesso aos plugins Premium do TinyMCE requer uma chave de API. Nem todos os plugins listados podem estar disponíveis com sua assinatura Premium do TinyMCE. Você pode verificar os plugins disponíveis na página da sua conta do <a target="_blank" href="https://www.tiny.cloud/my-account/integrate/">Tiny Cloud</a>.';
$string['premiumplugins_settings'] = 'Configurações do plugin TinyMCE Premium';
$string['privacy:metadata'] = 'O plugin premium do Tiny para TinyMCE não armazena nenhum dado pessoal.';
$string['serverside:desc'] = 'O plugin {$a} usa um serviço do lado do servidor para processar dados. Você pode optar por usar o serviço Tiny Cloud ou conectar-se à sua própria instância hospedada usando uma URL de serviço.';
$string['serverside:service'] = 'Serviço do lado do servidor';
$string['serverside:service:selfhosted'] = 'Use serviço próprio hospedado';
$string['serverside:service:tinycloud'] = 'Usar Tiny Cloud';
$string['serviceurl'] = 'URL do serviço';
$string['serviceurl:desc'] = 'Digite a URL do seu próprio serviço {$a} hospedado. <a href="https://www.tiny.cloud/docs/tinymce/latest/bundle-intro-setup/" target="_blank">Veja o guia de configuração do Tiny</a>.';
