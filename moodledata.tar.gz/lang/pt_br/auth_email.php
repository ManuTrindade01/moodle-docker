<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_email', language 'pt_br', version '5.2'.
 *
 * @package     auth_email
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['auth_emaildescription'] = '<p>O auto-registro por e-mail permite que o usuário crie sua própria conta por meio do botão \'Criar nova conta\' na página de login. Em seguida, o usuário recebe um e-mail contendo um link seguro para uma página onde poderá confirmar a conta. Nos logins futuros, o nome de usuário e a senha são verificados em relação aos valores armazenados no banco de dados do Moodle.</p><p>Observação: além de habilitar o plugin, o auto-registro por e-mail também deve ser selecionado no menu suspenso de auto-registro na página \'Gerenciar autenticação\'.</p>';
$string['auth_emailnoemail'] = 'A tentativa de lhe enviar um e-mail falhou!';
$string['auth_emailrecaptcha'] = 'Adiciona uma confirmação visual/sonora para o formulário da página de auto-cadastro de usuários por e-mail. Isso protege seu site contra spammers e contribui para uma causa que vale à pena. Veja http://www.google.com/recaptcha para mais detalhes.';
$string['auth_emailrecaptcha_key'] = 'Ativar elemento reCAPTCHA';
$string['auth_emailsettings'] = 'Configurações';
$string['pluginname'] = 'Auto-cadastro por e-mail';
$string['privacy:metadata'] = 'O plugin de autenticação de auto-inscrição por e-mail não armazena nenhum dado pessoal.';
