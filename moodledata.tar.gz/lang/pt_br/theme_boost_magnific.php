<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'theme_boost_magnific', language 'pt_br', version '5.2'.
 *
 * @package     theme_boost_magnific
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['access_course'] = 'Acessar Curso';
$string['access_course_buy'] = 'Detalhes do curso';
$string['acctoolbar_access_declaration'] = 'Declaração de Acessibilidade';
$string['acctoolbar_btn_bright'] = 'Contraste Brilhante';
$string['acctoolbar_btn_cursor_black'] = 'Cursor Grande Preto';
$string['acctoolbar_btn_cursor_white'] = 'Cursor Grande Branco';
$string['acctoolbar_btn_font_down'] = 'Diminuir Texto';
$string['acctoolbar_btn_font_readable'] = 'Texto Legível';
$string['acctoolbar_btn_font_up'] = 'Aumentar Texto';
$string['acctoolbar_btn_images_titles'] = 'Títulos das Imagens';
$string['acctoolbar_btn_invert'] = 'Inverter Contraste';
$string['acctoolbar_btn_monochrome'] = 'Exibição Sem Cores';
$string['acctoolbar_btn_open'] = 'Menu de Acessibilidade';
$string['acctoolbar_btn_underline_headers'] = 'Sublinhar Cabeçalhos';
$string['acctoolbar_btn_underline_links'] = 'Sublinhar Links';
$string['acctoolbar_btn_zoom_in'] = 'Ampliar Tela';
$string['acctoolbar_content_block_header'] = 'Destacar Conteúdo';
$string['acctoolbar_contrast_block_header'] = 'Contraste de Cores';
$string['acctoolbar_debug_contacts'] = 'Relatar um Problema de Acessibilidade';
$string['acctoolbar_disable_animattions'] = 'Bloquear Animações';
$string['acctoolbar_dyslexic'] = 'Fonte Legível para Dislexia';
$string['acctoolbar_image_without_alt'] = 'Imagem sem Texto';
$string['acctoolbar_keyboard_root'] = 'Navegação por Teclado';
$string['acctoolbar_reset_all_settings'] = 'Redefinir Configurações';
$string['acctoolbar_text_block_header'] = 'Tamanho do Texto';
$string['acctoolbar_toolbar'] = 'Barra de Ferramentas de Acessibilidade';
$string['acctoolbar_zoom_block_header'] = 'Aproximar';
$string['add_block'] = '+ Adicionar novo bloco';
$string['background_color'] = 'Cor de fundo';
$string['background_color_desc'] = 'Cor de fundo do Topo e Rodapé!';
$string['background_color_random'] = 'Tema Randômico {$a}';
$string['background_course_image'] = 'Imagem de Fundo Padrão do Curso';
$string['background_course_image_desc'] = 'Define uma imagem de fundo padrão para o cabeçalho de todos os cursos. Esta imagem será exibida no topo da página do curso e pode ser substituída individualmente nas configurações do curso.';
$string['background_profile_image'] = 'Imagem de Fundo do Perfil';
$string['background_profile_image_desc'] = 'Imagem de fundo exibida no perfil do usuário.';
$string['background_text_color'] = 'Cor do Texto';
$string['background_text_color_desc'] = 'Cor do texto do topo e do rodapé!';
$string['backgroundimage'] = 'Imagem de fundo';
$string['backgroundimage_desc'] = 'A imagem exibida como fundo do site. A imagem de fundo que você enviar aqui substituirá a imagem de fundo nos arquivos de predefinição do tema.';
$string['brandcolor'] = 'Cor primária da interface';
$string['brandcolor_background_menu'] = 'Aplicar cor da marca ao fundo do menu';
$string['brandcolor_background_menu_desc'] = 'Esta configuração define se a cor definida em "Cor da marca" será aplicada aos itens do menu ou ao fundo do menu.<br>Se aplicada ao fundo, o texto do menu será exibido em branco para garantir contraste adequado.';
$string['brandcolor_desc'] = 'Defina a cor de destaque usando a seleção acima ou escolhendo na paleta abaixo.';
$string['cachedef_course_cache'] = 'Cache de dados do curso';
$string['cachedef_course_module_cache'] = 'Cache de módulos do curso';
$string['cachedef_css_cache'] = 'Cache de CSS';
$string['cachedef_darkmode_cache'] = 'Cache do Modo Escuro';
$string['cachedef_data_cache'] = 'Cache de dados';
$string['cachedef_frontpage_cache'] = 'Cache da página inicial';
$string['cachedef_layout_cache'] = 'Cache do Layout';
$string['cachedef_logo_cache'] = 'Cache do Logotipo';
$string['choosereadme'] = 'O Boost Magnific é um tema cuidadosamente elaborado para adicionar cores vibrantes e uma atmosfera alegre ao Moodle.';
$string['contact_address'] = 'Endereço';
$string['contact_email'] = 'E-mail';
$string['contact_phone'] = 'Número de Telefone';
$string['content_type_default'] = 'Padrão do Moodle';
$string['content_type_empty'] = '(Nenhum conteúdo)';
$string['content_type_footer'] = 'Tipo de conteúdo para o rodapé';
$string['content_type_footer_desc'] = 'Selecione o tipo de conteúdo que deseja exibir no rodapé.';
$string['content_type_home'] = 'Tipo de conteúdo para a página inicial';
$string['content_type_home_desc'] = 'Selecione o tipo de conteúdo que deseja exibir na página inicial.';
$string['content_type_html'] = 'Página a ser criada com editor';
$string['continuar'] = 'Continuar estudando';
$string['countlesson'] = '{$a} lição';
$string['countlessons'] = '{$a} lições';
$string['course_access'] = 'Acesse o curso';
$string['course_moore'] = 'Mais detalhes';
$string['course_summary'] = 'Mostrar resumo do curso antes do Curso';
$string['course_summary_banner'] = 'Mostrar resumo do curso antes do Curso';
$string['course_summary_banner_desc'] = 'Se habilitado, o resumo do curso será exibido antes do conteúdo principal do curso na página do curso.';
$string['course_summary_banner_edit'] = 'Editar a imagem do banner deste curso';
$string['course_summary_banner_none'] = 'Sem cabeçalho';
$string['course_summary_banner_simple'] = 'Cabeçalho simples com informações';
$string['course_summary_banner_title'] = 'Cabeçalho com banner';
$string['course_summary_desc'] = 'Se habilitado, o resumo do curso será exibido antes do conteúdo principal do curso na página do curso.';
$string['courseindexoptions'] = 'Opções do índice do curso';
$string['coursesettings'] = 'Curso';
$string['customcss'] = 'CSS Customizados';
$string['customcss_desc'] = 'Quaisquer regras CSS que você adicionar a esta área de texto serão refletidas em todas as páginas, facilitando a personalização deste tema.';
$string['customfield_category_name'] = 'Personalização do Tema';
$string['customfield_field_image'] = 'Imagem Personalizada';
$string['customfield_field_image_desc'] = 'Selecione uma imagem para personalizar o campo. A imagem será exibida no layout e substituirá as configurações globais do curso.';
$string['customfield_field_name'] = 'Exibir Imagem no Topo do Curso';
$string['customfield_field_name_desc'] = '<p>Este campo permite escolher se deseja exibir uma imagem no topo da página do curso. Quando ativado, uma imagem de sua escolha será exibida de forma destacada, melhorando a aparência visual do curso e proporcionando uma experiência mais personalizada para os usuários.</p>';
$string['customfield_picture_missing'] = '<div class="alert alert-warning">Você precisa instalar o plugin <a href="https://moodle.org/plugins/customfield_picture" target="_blank">customfield_picture</a> para personalizar a imagem de fundo.</div>';
$string['custommenuitems'] = 'Itens Personalizados do Menu Superior';
$string['custommenuitems_desc'] = 'Você pode criar um menu personalizado ao lado dos menus superiores. O menu raiz deve começar junto à borda e os submenus devem ser precedidos por um hífen (-). O número de hífens determina a profundidade do item. Assim, os itens com um único hífen aparecem em um submenu abaixo do item de nível superior anterior, e os itens com dois hífens aparecem em um submenu seguido do subitem.
O conteúdo de cada item do menu deve ser composto por até três elementos (<strong>label</strong> | <strong>url</strong> | <strong>tooltip</strong> | <strong>lang</strong>), cada um separado pelo caractere "|".
<ul>
<li><strong>label</strong>: Este é o texto que será exibido dentro do item de menu. Você deve especificar um rótulo para cada item do menu.</li>
<li><strong>url</strong>: Este é o URL para o qual o usuário será levado ao clicar no item de menu. Isso é opcional; se não fornecido, o item não será vinculado a nenhum lugar.<br>
Outros atributos, como "target", podem ser adicionados ao final do URL.</li>
<li><strong>tooltip</strong>: Se você fornecer um URL, também pode optar por fornecer uma dica de ferramenta para o link criado com o URL. Isso é opcional e, se não definido, o rótulo é usado como dica de ferramenta para o item de menu.</li>
<li><strong>lang</strong>: Você pode adicionar um código de idioma (ou uma lista de códigos separados por vírgula) como o quarto elemento da linha. A linha será exibida somente se o usuário tiver selecionado o idioma listado.</li>
</ul>
A seguir, um exemplo de como você criaria um menu personalizado:
<blockquote><pre>
Cursos
-Todos os cursos | /course/
-Meus cursos
--Curso de Exemplo
---Curso Exemplo 7 | /course/view.php?id=7
---Curso Exemplo 9 | /course/view.php?id=9
--Curso de Testes
---Curso Testes 2 | /course/view.php?id=2
---Curso Testes 5 | /course/view.php?id=5
Google
-Google em qualquer idioma | https://google.com/" target="_blank
-Google em Mexico | https://www.google.com.mx/" target="_blank|Label do Google|en
-Google em português | https://google.com.br/" target="_blank|Label do Google|pt,pt_br,pt_br_kids
Página de Suporte | https://suporte.com/" target="_blank
</pre></blockquote>
Para o Moodle com suporte a múltiplos idiomas, o valor do <strong>label</strong> deve ser montado no formato <strong>"langstringname,componentname"</strong>.
<blockquote><pre>
profile,moodle | /user/profile.php
messages,message | /message/index.php
</pre></blockquote>
<a href="https://docs.moodle.org/404/en/Advanced_theme_settings" target="_blank">Mais informações do menu</a>';
$string['delete_block_confirm'] = 'Tem certeza de que deseja excluir o bloco?';
$string['delete_block_success'] = 'Bloco excluído com sucesso';
$string['delete_block_title'] = 'Excluir bloco';
$string['details-completaram'] = 'Curso concluído';
$string['details-emprogresso'] = 'Em andamento';
$string['details-not-access'] = 'Nunca acessado';
$string['details-teachers'] = 'Professores';
$string['details-users'] = 'Estudantes';
$string['edit_block'] = 'Editar bloco';
$string['editor_link_footer'] = 'Editar o bloco do rodapé para o idioma {$a}';
$string['editor_link_footer_all'] = 'Editar o bloco do rodapé para todos os idiomas';
$string['editor_link_home'] = 'Editar a página inicial para o idioma {$a}';
$string['editor_link_home_all'] = 'Editar a página inicial para todos os idiomas';
$string['favicon'] = 'Favicon';
$string['favicon_desc'] = 'O favicon é exibido ao lado do título da página na guia do navegador. Um favicon do Moodle é exibido se um favicon personalizado não for fornecido.';
$string['fontfamily'] = 'Fonte do site';
$string['fontfamily_desc'] = 'Escolha quanfonte você quer suar no seu Moodle';
$string['fontfamily_menus'] = 'Fontes do Menu';
$string['fontfamily_menus_desc'] = 'Escolha qual fonte deseja usar para os menus em seu site Moodle.';
$string['fontfamily_sitename'] = 'Fonte para o nome do site';
$string['fontfamily_sitename_desc'] = 'A fonte que será aplicada ao nome do site se um logotipo não for fornecido.';
$string['fontfamily_title'] = 'Fontes para Texto de Título';
$string['fontfamily_title_desc'] = 'Escolha qual fonte deseja usar para os títulos em seu site Moodle.';
$string['fontpreview'] = 'Prévia da Lista de Fontes';
$string['footer_background_color'] = 'Cor de fundo do rodapé';
$string['footer_background_color_desc'] = 'Selecione a cor de fundo para a seção de rodapé do site. Deixe em branco para usar a cor primária.';
$string['footer_contact_title'] = 'Título do Bloco de Contato';
$string['footer_contact_title_default'] = 'Entre em contato';
$string['footer_contact_title_desc'] = 'Coloque o título do Bloco que aparecerá no Rodapé com os dados de contato.';
$string['footer_copywriter'] = 'Feito com ❤️';
$string['footer_description'] = 'Descrição';
$string['footer_description_desc'] = 'Descreva seu Moodle, o que você faz, e está nformação será mostrada abaixo do logo no Rodapé do Moodle';
$string['footer_frontpage_blockcourses_instructor'] = 'Mostrar nome do Professor';
$string['footer_frontpage_blockcourses_instructor_desc'] = 'Se marcado, mostra os nomes dos professores na lista de cursos!';
$string['footer_frontpage_blockcourses_text'] = 'Texto curto explicando o bloco "{$a}"';
$string['footer_frontpage_blockcourses_text_desc'] = 'Adicone um texto falando dos "{$a}"!';
$string['footer_heading'] = 'Bloco {$a}';
$string['footer_heading_description_desc'] = '<ul>
  <li><strong>Nenhum bloco preenchido:</strong> o rodapé não será exibido.</li>
  <li><strong>1 bloco preenchido:</strong> o conteúdo será exibido como texto, sem formatação de bloco.</li>
  <li><strong>2, 3 ou 4 blocos preenchidos:</strong> o tema ajustará automaticamente o layout para exibir os blocos de forma responsiva e proporcional.</li>
</ul>
Preencha apenas os blocos necessários, o tema cuida do restante.';
$string['footer_heading_description_title'] = 'O tema se adapta automaticamente ao número de blocos de rodapé preenchidos:';
$string['footer_html'] = 'Rodapé Bloco {$a} HTML';
$string['footer_html_desc'] = 'Adicione o código HTML personalizado que será exibido no bloco de rodapé {$a}.';
$string['footer_links_title'] = 'Título do Bloco dos Links';
$string['footer_links_title_default'] = 'Links importantes';
$string['footer_show_copywriter'] = 'Mostrar o Feito com ❤️';
$string['footer_show_copywriter_desc'] = 'Desmarque caso deseja ocultar o "Feito com ❤️"';
$string['footer_social_title'] = 'Título do Bloco das redes sociais Social';
$string['footer_social_title_default'] = 'Nos siga nas redes sociais';
$string['footer_social_title_desc'] = 'Coloque o título do Bloco que aparecerá no Rodapé com os dados de das suas redes sociais.';
$string['footer_title'] = 'Título do Bloco {$a}';
$string['footer_title_desc'] = 'Defina o título que aparecerá acima do conteúdo HTML no bloco de rodapé {$a}.';
$string['footerblink'] = 'Links do Bloco de Rodapé';
$string['footerblink_desc'] = 'Você pode configurar um Bloco de Rodapé Links aqui para serem mostrados por temas. <br>Cada linha consiste em algum texto de menu ou chave de idioma ou texto, um URL de link (opcional),separado por barras verticais.Por exemplo:<br><pre>Moodle Support|https://moodle.org/support</pre>';
$string['footerblock_contact'] = 'Bloco de contato';
$string['footerblock_copywriter'] = 'Feito com ❤️';
$string['footerblock_description'] = 'Bloco de descrição';
$string['footerblock_links'] = 'Bloco dos links';
$string['footerblock_social'] = 'Bloco do Social';
$string['footersettings'] = 'Configurações do Rodapé';
$string['free_name'] = 'Gratis';
$string['frontpage_about_description'] = 'Descreva o que vocês fazem';
$string['frontpage_about_description_desc'] = 'Descreva em no máximo 5 linhas qual a finalidade do seu Moodle';
$string['frontpage_about_enable'] = 'Habilitar bloco Sobre';
$string['frontpage_about_enable_desc'] = 'Se marcado, o Bloco sobre aparecerá abaixo do Banner!';
$string['frontpage_about_info'] = 'Caixa de dados {$a}';
$string['frontpage_about_logo'] = 'Logo diferente a ser mostrado aqui';
$string['frontpage_about_logo_desc'] = 'Se definido, será usado esta logo aqui, ao invés da logo do Topo.<br>
                                         Em branco usa a Logo do TOPO!';
$string['frontpage_about_number'] = 'Quantidade de dados';
$string['frontpage_about_number_desc'] = 'Coloque aqui a quantidade de informação acima citado';
$string['frontpage_about_text'] = 'Nome do dado';
$string['frontpage_about_text_1_defalt'] = 'Cursos';
$string['frontpage_about_text_2_defalt'] = 'Professores';
$string['frontpage_about_text_3_defalt'] = 'Estudantes';
$string['frontpage_about_text_4_defalt'] = 'Lições';
$string['frontpage_about_text_desc'] = 'Coloque aqui o nome do dado que será mostrado na home';
$string['frontpage_about_title'] = 'Título do bloco Sobre';
$string['frontpage_about_title_default'] = 'Nossa Comunidade Global';
$string['frontpage_add_block'] = 'Adicionar novo bloco';
$string['frontpage_add_block_title'] = 'Selecione o bloco de exemplo para adicionar';
$string['frontpage_change_editor'] = 'Criar a página inicial com o editor de páginas?';
$string['frontpage_enable_editing'] = 'Ative a edição para adicionar itens à página inicial';
$string['heart'] = 'Se está gostando desse tema, não esqueça de clicar em ❤️ na página dos themas <a href="{$a}" target="_blank">clicando aqui</a>';
$string['homesettings'] = 'Configurações da Página Inicial';
$string['imageacceptedtypes'] = 'Somente arquivos de imagem do tipo {$a} são permitidos';
$string['instructor'] = 'Professor';
$string['language_all'] = 'Todos os idiomas disponíveis';
$string['login_backgroundcolor'] = 'Cor de fundo';
$string['login_backgroundcolor_desc'] = 'Selecione a cor de fundo da página de recuperar senha';
$string['login_backgroundfoto'] = 'Imagem de fundo';
$string['login_backgroundfoto_desc'] = 'Selecione a imagem de fundo do Login/Recuperar Senha/Criar Conta. Imagem padrão é: {$a}';
$string['login_forgot_description'] = 'Texto na lateral da Tela de Recuperar Senha';
$string['login_forgot_description_desc'] = 'Texto que aparecerá apenas na tela de Recuperar Senha';
$string['login_login_description'] = 'Texto na lateral da Tela de Login';
$string['login_login_description_desc'] = 'Texto que aparecerá apenas na tela de Login';
$string['login_signup_description'] = 'Texto na lateral da Tela de Criar uma conta';
$string['login_signup_description_desc'] = 'Texto que aparecerá apenas na tela de Criar uma conta';
$string['login_theme'] = 'Tema do login';
$string['login_theme_block'] = 'Bloco branco central com background opcional';
$string['login_theme_desc'] = 'Escolha qual tema quer na área de Login';
$string['login_theme_image_login'] = 'Imagem de background e login do lado';
$string['login_theme_imagetext_login'] = 'Imagem de background, texto sobre a imagem e login do lado';
$string['login_theme_login'] = 'Apenas tela de login, sem imagem lateral';
$string['loginbackgroundimage'] = 'Imagem de fundo da página de login';
$string['loginbackgroundimage_desc'] = 'A imagem a ser exibida como fundo da página de login.';
$string['logo_color'] = 'Logo colorida';
$string['logo_color_desc'] = 'Por favor, faça o upload da sua LOGO colorida caso queira incluí-la no topo. Esta logo será exibida conforme a página é rolada, e o menu será exibido em fundo branco.';
$string['logo_write'] = 'Logotipo do menu superior ao rolar';
$string['logo_write_desc'] = 'Por favor, faça o upload do seu logotipo se deseja incluí-lo na parte superior. Este logotipo será exibido quando a rolagem permanecer no topo, e o menu será exibido em um fundo colorido.';
$string['matricular'] = 'Matricule-se';
$string['mycourses_color'] = 'Cor de Fundo do Bloco';
$string['mycourses_color_desc'] = 'A cor de fundo para o bloco.';
$string['mycourses_icon'] = 'Ícone';
$string['mycourses_icon_desc'] = 'Um ícone representativo para o bloco. O tamanho do ícone deve ser 48x48 pixels.';
$string['mycourses_info'] = 'Bloco {$a}';
$string['mycourses_numblocos'] = 'Sem blocos';
$string['mycourses_numblocos_desc'] = 'Quantas imagens você quer no SlideShow?';
$string['mycourses_numblocos_nenhum'] = 'Sem slides na página inicial';
$string['mycourses_title'] = 'Título Curto do Bloco';
$string['mycourses_title_desc'] = 'Um título curto e descritivo para o bloco.';
$string['mycourses_url'] = 'Link do Bloco';
$string['mycourses_url_desc'] = 'A URL para navegar ao clicar no bloco. Pode ser um link externo ou um link interno dentro da plataforma.';
$string['pluginname'] = 'Boost Magnific';
$string['preview'] = 'Pré-visualização do bloco';
$string['privacy:drawerblockclosed'] = 'A preferência atual para a gaveta de blocos é fechada.';
$string['privacy:drawerblockopen'] = 'A preferência atual para a gaveta de blocos é aberta.';
$string['privacy:drawerindexclosed'] = 'A preferência atual para a gaveta de índice é fechada.';
$string['privacy:drawerindexopen'] = 'A preferência atual para a gaveta de índice é aberta.';
$string['privacy:metadata'] = 'O tema Boost Magnific não armazena nenhum dado pessoal sobre nenhum usuário.';
$string['privacy:metadata:preference:draweropenblock'] = 'A preferência do usuário para ocultar ou mostrar a gaveta com blocos.';
$string['privacy:metadata:preference:draweropenindex'] = 'A preferência do usuário para ocultar ou mostrar a gaveta com índice do curso.';
$string['privacy:metadata:preference:draweropennav'] = 'A preferência do usuário para ocultar ou mostrar o menu de navegação da gaveta.';
$string['progress_percentage'] = 'Seu Progresso';
$string['quickstart_alert_notadd'] = 'Não é possível alterar o banner da página inicial após ele ter sido adicionado. Para modificá-lo, vá até a <a href="{$a}/">página inicial</a> e exclua o banner existente.';
$string['quickstart_alert_notdelete'] = 'Não é possível remover blocos adicionados aqui. Para excluí-los, vá até a <a href="{$a}/">página inicial</a> e remova os blocos que não deseja mais.';
$string['quickstart_banner-recreation-room'] = 'Sala de recreação';
$string['quickstart_banner-saved'] = 'As configurações foram salvas com sucesso.';
$string['quickstart_course_choose_below'] = 'Ou escolha um banner abaixo';
$string['quickstart_course_upload_or_choose'] = 'Envie uma imagem ou escolha o tipo de banner desejado';
$string['quickstart_home_pagebuilder'] = 'Página inicial com Editor de Páginas';
$string['quickstart_home_pagebuilder_desc'] = 'Interface personalizável com seções editáveis.';
$string['quickstart_home_selectsections'] = 'Selecione as seções desejadas:';
$string['quickstart_home_selectstyle'] = 'Escolha o estilo da Página Inicial';
$string['quickstart_home_traditional'] = 'Página Inicial Tradicional do Moodle';
$string['quickstart_home_traditional_desc'] = 'Página inicial padrão do Moodle com blocos e cursos. Clique no botão abaixo para editar as configurações do sistema.';
$string['quickstart_settings_link'] = '<div class="card mb-5">
<div class="card-header">Início Rápido</div>
<div class="card-body"><a href="{$a}">Acesse o Guia de Início Rápido</a> e use o configurador intuitivo para personalizar estas e outras configurações do tema Boost Magnific.</div>
</div>';
$string['quickstart_title'] = 'Central de Configurações do Tema';
$string['settings_about_heading'] = 'Sobre seu Moodle';
$string['settings_accessibility'] = 'Ativar opções de acessibilidade';
$string['settings_accessibility_desc'] = 'Permite a personalização de opções para melhorar a acessibilidade da plataforma, como contraste, tamanho da fonte e navegação por teclado.';
$string['settings_accessibility_heading'] = 'Acessibilidade';
$string['settings_course_heading'] = 'Configurações do Curso';
$string['settings_css_heading'] = 'Fontes e CSS';
$string['settings_footer_heading'] = 'Bloco do Rodapé';
$string['settings_icons_change_icons'] = 'Mudar o ícone padrão na lista de cursos';
$string['settings_icons_color_icon'] = 'Defina uma cor personalizada para o ícone.';
$string['settings_icons_color_icon_desc'] = 'Selecione a cor de fundo do ícone exibido na lista de cursos. Deixe em branco para usar a cor padrão do tema.';
$string['settings_icons_upload_icon'] = 'Enviar o ícone personalizado.';
$string['settings_icons_upload_image'] = 'Imagem do Bloco';
$string['settings_icons_upload_image_desc'] = 'Se uma imagem for fornecida, o tema converterá a linha do módulo em um bloco, usando a imagem como plano de fundo. A imagem deve ter proporção de 16:9.';
$string['settings_login_heading'] = 'Tela de Login';
$string['settings_mycourses_heading'] = 'Blocos dos Meus Cursos';
$string['settings_slideshow_heading'] = 'SlideShow';
$string['settings_theme_heading'] = 'Tema';
$string['settings_top_heading'] = 'Menu Superior';
$string['showfooter'] = 'Exibir rodapé';
$string['sitefonts'] = 'Fontes Adicionais do Google';
$string['sitefonts_desc'] = 'Insira o código @import do Google Fonts conforme indicado na imagem abaixo. Após salvar, o campo "Fonte do Site" será atualizado, exibindo essas fontes. Você pode adicionar vários @import conforme necessário.';
$string['slidecaption_desc'] = 'Digite o texto da legenda a ser usado no slide';
$string['slideshow_image'] = 'Imagem do Slide';
$string['slideshow_image_desc'] = 'A imagem deve ter 1250px X 400px.';
$string['slideshow_info'] = 'Slide {$a}';
$string['slideshow_numslides'] = 'Quantos imagens no SlideShow';
$string['slideshow_numslides_desc'] = 'Quantas imagens queres no SlideShow?';
$string['slideshow_numslides_nenhum'] = 'Sem slide na Home';
$string['slideshow_text'] = 'Texto curto descritivo do Slide';
$string['slideshow_text_desc'] = 'Insira um pequenos textos sobre o slide.';
$string['slideshow_url'] = 'Link do botão dos slides';
$string['slideshow_url_desc'] = 'Insira o destino de destino do link do botão de imagem do slide';
$string['social_facebook'] = 'Seu Facebook';
$string['social_facebook_desc'] = 'A URL do Facebook da sua organização.';
$string['social_instagram'] = 'Seu Instagram';
$string['social_instagram_desc'] = 'A URL do Instagram da sua organização.';
$string['social_linkedin'] = 'Seu Linkedin';
$string['social_linkedin_desc'] = 'A URL do Linkedin da sua organização.';
$string['social_twitter'] = 'Seu Twitter';
$string['social_twitter_desc'] = 'A URL do Twitter da sua organização.';
$string['social_youtube'] = 'Seu Youtube';
$string['social_youtube_desc'] = 'A URL do Youtube da sua organização.';
$string['tableofcontents'] = 'Tabela de Conteúdos';
$string['theme_boost_magnific_about_editbooton'] = 'Editar bloco Sobre';
$string['theme_boost_magnific_frontpage_bloco'] = 'Bloco "{$a}"';
$string['theme_boost_magnific_frontpage_home'] = 'Blocos da Home';
$string['theme_boost_magnific_mycourses_editbooton'] = 'Editar Blocos';
$string['theme_boost_magnific_slideshow_editbooton'] = 'Editar SlideShow';
$string['theme_color'] = 'Seleção de cores';
$string['theme_color-color_buttons'] = 'Cor dos Botões';
$string['theme_color-color_buttons_desc'] = 'A cor usada para os botões, adicionando coesão visual e enfatizando ações interativas.';
$string['theme_color-color_primary'] = 'Cor Primária';
$string['theme_color-color_primary_desc'] = 'A cor primária principal do tema, geralmente usada para elementos de destaque e ênfase.';
$string['theme_color-color_secondary'] = 'Cor Secundária';
$string['theme_color-color_secondary_desc'] = 'Uma cor secundária que complementa a cor primária, usada para realçar elementos secundários ou para contrastar com a cor primária.';
$string['theme_color_desc'] = 'Selecione as cores dos textos e botões do Moodle ou clique na linha abaixo:';
$string['theme_color_heading'] = 'Seleção de cores do ambiente';
$string['theme_color_sugestion'] = 'Sugestão de cor';
$string['theme_color_sugestion_text'] = 'Clique na linha para aplicar a cor nos campos abaixo:';
$string['theme_login_branco'] = 'Apenas tela de login, sem imagem lateral, com o form em fundo branco';
$string['top_color_heading'] = 'Cor do topo ao rolar';
$string['top_scroll'] = 'Fixar o menu ao rolar a página';
$string['top_scroll_background_color'] = 'Cor de fundo do menu do topo ao rolar';
$string['top_scroll_background_color_desc'] = 'Defina a cor de fundo ao rolar a página.';
$string['top_scroll_desc'] = 'Quando ativado, o menu ficará fixo no topo da tela enquanto você rola a página, garantindo fácil acesso às opções do menu.';
$string['top_scroll_fix'] = 'Fixar o menu ao rolar a página';
$string['top_scroll_fix_desc'] = 'Quando habilitado, o menu ficará fixo no topo da tela enquanto você rola a página, garantindo fácil acesso às opções do menu.';
$string['top_scroll_text_color'] = 'Cor do texto do menu ao rolar';
$string['top_scroll_text_color_desc'] = 'Defina a cor do texto do menu ao rolar a página.';
$string['userprofilesettings'] = 'Perfil do Usuário';
$string['vvveb_footer_contact_title_default'] = 'Contate-nos';
$string['vvveb_home_access'] = 'Acessar curso';
$string['vvveb_home_automatically_catalogo'] = 'Não edite. Este bloco será automaticamente substituído pelo catálogo de cursos.';
$string['vvveb_home_automatically_category'] = 'Não edite. Este bloco será automaticamente substituído pelas categorias de cursos.';
$string['vvveb_home_automatically_my_course'] = 'Não edite. Este bloco será substituído automaticamente pelos cursos em que o aluno está matriculado.';
$string['vvveb_home_automatically_popular'] = 'Não edite. Este bloco será automaticamente substituído pelos cursos mais populares.';
$string['vvveb_home_catalogo_heading'] = 'Catálogo de cursos';
$string['vvveb_home_category_heading'] = 'Categorias de cursos';
$string['vvveb_home_mycourses_heading'] = 'Meus Cursos';
$string['vvveb_home_popular_course'] = 'Cursos Populares';
$string['vvveb_home_team_subtitle'] = 'Somos um grupo de profissionais dedicados ao seu trabalho';
$string['vvveb_home_team_title'] = 'Conheça Nossa Equipe';
