<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'theme_govbrds', language 'pt_br', version '5.2'.
 *
 * @package     theme_govbrds
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['about'] = 'Sobre';
$string['accessibility'] = 'Acessibilidade';
$string['address'] = 'Endereço';
$string['address_desc'] = 'JSON do endereço que você deseja exibir no rodapé.';
$string['addressm'] = 'Rodapé Manual';
$string['addressm_desc'] = 'Digite algo que você deseja exibir no rodapé.';
$string['advancedsettings'] = 'Configurações avançadas';
$string['all_rights_reserved'] = 'Todos os direitos reservados';
$string['backgroundimage'] = 'Imagem de fundo';
$string['backgroundimage_desc'] = 'A imagem a ser exibida como plano de fundo do site. A imagem que você enviar aqui substituirá a imagem de plano de fundo padrão nos arquivos do tema.';
$string['boostset'] = 'Configuração do tema';
$string['brandcolor'] = 'Cor da marca';
$string['brandcolor_desc'] = 'A cor de destaque.';
$string['choosereadme'] = 'O tema GovBR-DS é um tema filho do Boost. Ele é baseado na identidade digital do governo brasileiro.';
$string['configtitle'] = 'Configurações do GovBR-DS';
$string['contact'] = 'Contato';
$string['course_deadline'] = 'Prazo final do curso';
$string['course_details'] = 'Detalhes do curso';
$string['courses'] = 'Cursos';
$string['currentinparentheses'] = '(atual)';
$string['development_team'] = 'Equipe de Desenvolvimento';
$string['email'] = 'E-mail';
$string['enddate'] = 'Data de término';
$string['facebook'] = 'Facebook';
$string['facebookdesc'] = 'Link para seu perfil do Facebook.';
$string['feature1content'] = 'Conteúdo da Funcionalidade 1';
$string['feature1heading'] = 'Cabeçalho da Funcionalidade 1';
$string['feature1icon'] = 'Ícone da Funcionalidade {$a}';
$string['feature2_btntext'] = 'Rótulo do Botão da Funcionalidade {$a}';
$string['feature2_btnurl'] = 'Link do Botão da Funcionalidade {$a}';
$string['feature2con_desc'] = 'Escolha um ícone para a funcionalidade {$a}. Veja a lista de ícones em https://fontawesome.com/icons?d=gallery&m=free.';
$string['feature2content'] = 'Conteúdo da Funcionalidade 2';
$string['feature2heading'] = 'Cabeçalho da Funcionalidade 2';
$string['feature2icon'] = 'Ícone da Funcionalidade {$a}';
$string['feature2icon_desc'] = 'Escolha um ícone para a funcionalidade {$a}. Veja a lista de ícones em https://fontawesome.com/icons?d=gallery&m=free.';
$string['feature3_btntext'] = 'Ícone da Funcionalidade {$a}';
$string['feature3_btnurl'] = 'Ícone da Funcionalidade {$a}';
$string['feature3content'] = 'Conteúdo da Funcionalidade 3';
$string['feature3heading'] = 'Cabeçalho da Funcionalidade 3';
$string['feature3icon'] = 'Ícone da Funcionalidade {$a}';
$string['feature3icon_desc'] = 'Escolha um ícone para a funcionalidade {$a}. Veja a lista de ícones em https://fontawesome.com/icons?d=gallery&m=free.';
$string['feature4_btntext'] = 'Ícone da Funcionalidade {$a}';
$string['feature4_btnurl'] = 'Ícone da Funcionalidade {$a}';
$string['feature4content'] = 'Conteúdo da Funcionalidade 4';
$string['feature4heading'] = 'Cabeçalho da Funcionalidade 4';
$string['feature4icon'] = 'Ícone da Funcionalidade {$a}';
$string['feature4icon_desc'] = 'Escolha um ícone para a funcionalidade {$a}. Veja a lista de ícones em https://fontawesome.com/icons?d=gallery&m=free.';
$string['feature_btntext'] = 'Rótulo do botão da funcionalidade {$a}';
$string['feature_btntext_desc'] = 'Insira um rótulo do botão da funcionalidade {$a}';
$string['feature_btnurl'] = 'Endereço do link do botão da funcionalidade {$a}';
$string['feature_btnurl_desc'] = 'Insira um o link do botão da funcionalidade {$a}';
$string['featurecontent'] = 'Conteúdo da Funcionalidade';
$string['featureheading'] = 'Cabeçalho da Funcionalidade';
$string['featureicon'] = 'Ícone da funcionalidade {$a}';
$string['featureicon_desc'] = 'Escolha um ícone para a funcionalidade {$a}. Veja a lista de ícones em https://fontawesome.com/icons?d=gallery&m=free.';
$string['features'] = 'Mostrar blocos de funcionalidades';
$string['featurescontent'] = 'Conteúdo da seção de funcionalidades';
$string['featuresdesc'] = 'Ative ou desative a exibição das caixas de funcionalidades na página inicial.';
$string['featuresheading'] = 'Título da seção de funcionalidades';
$string['generalsettings'] = 'Configurações gerais';
$string['herocta'] = 'Botão de CTA da área de destaque';
$string['herocta_desc'] = 'Texto para o botão de chamada para ação (CTA)';
$string['heroctalink'] = 'URL do botão de CTA na área de destaque';
$string['heroctalink_desc'] = 'Endereço do link do botão de ação na área de destaque.';
$string['herohtml'] = 'Área de destaque';
$string['herohtml_desc'] = 'Conteúdo da área de destaque da homepage';
$string['heroimage'] = 'Imagem de destaque';
$string['heroimage_desc'] = 'Imagem a ser exibida na seção de destaque. O formato recomendado é .png (PNG-24), sem fundo, com tamanho de 450x600 pixels (proporção 3x4).';
$string['heroimagealt'] = 'Texto alternativo da imagem de destaque';
$string['heroimagealt_desc'] = 'Texto alternativa da imagem de destaque, voltada à acessibilidade.';
$string['homepage'] = 'Página inicial';
$string['homepage_settings'] = 'Configurações da página inicial';
$string['how_to'] = 'Como funciona?';
$string['instagram'] = 'Instagram';
$string['instagramdesc'] = 'Link para seu perfil do Instagram.';
$string['layout'] = 'Layout';
$string['layout_desc'] = 'Escolha o layout do site.';
$string['linkedin'] = 'LinkedIn';
$string['linkedindesc'] = 'Link para seu perfil do LinkedIn.';
$string['listcoursestitle'] = 'Título dos Cursos da Lista';
$string['listcoursestitle_desc'] = 'Título da seção de cursos na página inicial.';
$string['logo'] = 'Seu logotipo';
$string['logo_desc'] = 'Carregue a imagem do logotipo que será exibida no cabeçalho do site. O tamanho recomendado é 280x80 pixels.';
$string['message_content'] = 'Conteúdo da mensagem em destaque';
$string['message_content_desc'] = 'Conteúdo da mensagem destacada na página inicial.';
$string['message_title'] = 'Título da mensagem em destaque';
$string['message_title_desc'] = 'Título da mensagem destacada na página inicial.';
$string['next_activity'] = 'Próxima atividade';
$string['no_related_course'] = 'Nenhum curso relacionado';
$string['no_teacher'] = 'Sem professor';
$string['organization'] = 'Organização';
$string['organization_desc'] = 'Descrição da instituição.';
$string['organization_url'] = 'URL da Organização';
$string['organization_url_desc'] = 'Link para a página inicial da instituição.';
$string['partners'] = 'Parceiros';
$string['partners_desc'] = 'Faça o upload da imagem do logo que será exibida no rodapé do site. O tamanho recomendado é 280x80 pixels.';
$string['phone'] = 'Telefone';
$string['pluginname'] = 'GovBR-DS';
$string['preset'] = 'Predefinição de tema';
$string['preset_desc'] = 'Escolha uma predefinição para alterar a aparência do tema.';
$string['presetfiles'] = 'Arquivos de predefinições de temas adicionais';
$string['presetfiles_desc'] = 'Arquivos de predefinições podem ser usados para alterar drasticamente a aparência do tema. Consulte <a href=https://docs.moodle.org/dev/Boost_Presets>Predefinições de reforço</a> para obter informações sobre como criar e compartilhar suas próprias predefinições e consulte o <a href=http://moodle.net/boost>Repositório de predefinições</a> para ver as predefinições compartilhadas por outros.';
$string['prev_activity'] = 'Atividade anterior';
$string['privacy:metadata:govbrds_user_setting'] = 'Armazena preferências de configuração de tema específicas do usuário.';
$string['privacy_policy'] = 'Política de Privacidade';
$string['rawscss'] = 'SCSS bruto';
$string['rawscss_desc'] = 'Use este campo para fornecer o código SCSS ou CSS que será injetado no final da folha de estilo.';
$string['rawscsspre'] = 'SCSS bruto inicial';
$string['rawscsspre_desc'] = 'Use este campo para fornecer o código SCSS de inicialização. Ele será injetado antes de todo o resto. Na maioria das vezes, você usará esta configuração para definir variáveis.';
$string['region-footer-left'] = 'Rodapé (Esquerda)';
$string['region-footer-middle'] = 'Rodapé (Meio)';
$string['region-footer-right'] = 'Rodapé (Direita)';
$string['region-hidden-dock'] = 'Oculto dos usuários';
$string['region-home-left'] = 'Início (Esquerda)';
$string['region-home-middle'] = 'Início (Meio)';
$string['region-home-right'] = 'Início (direita)';
$string['region-side-post'] = 'Direita';
$string['region-side-pre'] = 'Esquerda';
$string['related_courses'] = 'Cursos relacionados';
$string['search'] = 'Procurar';
$string['searchtext'] = 'Pesquisar texto';
$string['sitemap'] = 'Mapa do site';
$string['socialsettings'] = 'Configuração de Redes Sociais';
$string['startdate'] = 'Data de início';
$string['subordination'] = 'Subordinação';
$string['subordination_desc'] = 'Ministério ao qual pertence.';
$string['terms_of_use'] = 'Termos de Uso';
$string['tiktok'] = 'Tik Tok';
$string['tiktokdesc'] = 'Link para seu perfil do Tik Tok.';
$string['to'] = 'para';
$string['twitter'] = 'Twitter';
$string['twitterdesc'] = 'Link para seu perfil do Twitter.';
$string['useful_links'] = 'Links úteis';
$string['youtube'] = 'YouTube';
$string['youtubedesc'] = 'Link para seu perfil do YouTube.';
