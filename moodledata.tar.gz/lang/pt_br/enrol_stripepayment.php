<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_stripepayment', language 'pt_br', version '5.2'.
 *
 * @package     enrol_stripepayment
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assignrole'] = 'Atribuir papel';
$string['canntenrol'] = 'A inscrição está desabilitada ou inativa';
$string['cost'] = 'Custo de inscrição';
$string['costerror'] = 'O custo de inscrição não é numérico';
$string['couponcode'] = 'Código do cupom';
$string['currency'] = 'Moeda';
$string['defaultrole'] = 'Atribuição de papel padrão';
$string['enrol'] = 'Inscrever';
$string['enrolenddate'] = 'Data final';
$string['enrolenddate_help'] = 'Se habilitado, os usuários podem ser inscritos somente até esta data.';
$string['enrolenddaterror'] = 'A data de término da inscrição não pode ser anterior à data de início';
$string['enrolperiod'] = 'Duração da inscrição';
$string['enrolperiod_help'] = 'Período de tempo em que a inscrição é válida, começando no momento em que o usuário é inscrito. Se desativado, a duração da inscrição será ilimitada.';
$string['enrolstartdate'] = 'Data de início';
$string['enrolstartdate_help'] = 'Se habilitado, os usuários podem ser inscritos somente a partir desta data.';
$string['error'] = 'Erro!';
$string['expiredaction'] = 'Ação após o término da inscrição';
$string['invalidcontextid'] = 'Não é um ID de contexto válido!';
$string['invalidcoupon'] = 'Cupom inválido!';
$string['invalidcourseid'] = 'Não é um ID de curso válido!';
$string['invalidinstance'] = 'Não é uma ID de instância válida!';
$string['invalidrequest'] = 'Solicitação Inválida!';
$string['mailadmins'] = 'Notificar o administrador';
$string['mailstudents'] = 'Notificar os estudantes';
$string['mailteachers'] = 'Notificar os professores';
$string['maxenrolled'] = 'Máximo de usuários inscritos';
$string['maxenrolled_help'] = 'Especifica o número máximo de usuários que podem se inscrever no pagamento parcelado. 0 significa sem limite.';
$string['maxenrolledreached'] = 'O número máximo de usuários com permissão para inscrição de pagamento parcelado já foi atingido.';
$string['messageprovider:stripepayment_enrolment'] = 'Provedor de mensagens';
$string['pluginname'] = 'Pagamento Stripe';
$string['publishablekey'] = 'Chave publicável Stripe';
$string['secretkey'] = 'Chave Secreta Stripe';
$string['sessioncreated'] = 'Checkout da sessão criado com sucesso!';
$string['sessioncreatefail'] = 'Falha na criação do checkout da sessão!';
$string['status'] = 'Permitir inscrições do Stripe';
$string['status_desc'] = 'Permitir que os usuários usem o Stripe para se inscrever em um curso por padrão.';
$string['stripe:config'] = 'Configurar instâncias de inscrição do Stripe';
$string['stripe:manage'] = 'Gerenciar usuários inscritos';
$string['stripe:unenrol'] = 'Cancelar a inscrição de usuários do curso';
$string['stripe:unenrolself'] = 'Cancelar a sua inscrição no curso';
$string['stripeerror'] = 'Erro do Stripe';
$string['stripepayment:config'] = 'Configurar';
$string['stripepayment:manage'] = 'Gerenciar';
$string['stripepayment:unenrol'] = 'Cancelar inscricão';
$string['stripepayment:unenrolself'] = 'Desinscrever-se';
$string['unenrolselfconfirm'] = 'Deseja mesmo cancelar a sua inscrição no curso "{$a}"?';
