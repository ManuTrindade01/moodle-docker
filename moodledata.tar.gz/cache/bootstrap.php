<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'DAfHJ3pkIhhmdy2fMOXAsyFcadMGLDp4localhost';
$CFG->bootstraphash = 'df1facad159a3f37363e5a37791fa7bb';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
