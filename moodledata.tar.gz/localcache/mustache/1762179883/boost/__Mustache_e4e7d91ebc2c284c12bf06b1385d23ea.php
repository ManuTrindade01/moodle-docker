<?php

class __Mustache_e4e7d91ebc2c284c12bf06b1385d23ea extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '</div>
';

        return $buffer;
    }
}
