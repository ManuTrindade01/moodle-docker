<?php

class __Mustache_29361cdada5fb357edc58af66d7dfa3c extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<span class="visually-hidden-focusable" data-region="jumpto" tabindex="-1"></span>
';

        return $buffer;
    }
}
