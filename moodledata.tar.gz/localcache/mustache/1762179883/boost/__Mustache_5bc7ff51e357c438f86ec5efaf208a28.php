<?php

class __Mustache_5bc7ff51e357c438f86ec5efaf208a28 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<div class="toast-wrapper mx-auto py-0 fixed-top" role="status" aria-live="polite"></div>
';

        return $buffer;
    }
}
